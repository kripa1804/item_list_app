package com.example.item_list_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
